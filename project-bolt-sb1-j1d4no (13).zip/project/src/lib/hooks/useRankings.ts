import { useQuery } from '@tanstack/react-query';
import { collection, query, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase';
import type { Community, User } from '../types';

export function useRankings() {
  return useQuery({
    queryKey: ['rankings'],
    queryFn: async () => {
      // Get all communities
      const communitiesRef = collection(db, 'communities');
      const communitiesQuery = query(
        collection(db, 'communities'),
        orderBy('created_at', 'desc'),
        limit(10)
      );
      
      const communitiesSnapshot = await getDocs(communitiesQuery);
      const communities = communitiesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Community[];

      // Get all creators (users)
      const creatorsRef = collection(db, 'users');
      const creatorsQuery = query(
        collection(db, 'users'),
        orderBy('created_at', 'desc'),
        limit(10)
      );
      
      const creatorsSnapshot = await getDocs(creatorsQuery);
      const creators = creatorsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as User[];

      return { communities, creators };
    },
    staleTime: 1000 * 60, // 1 minute
    retry: 2
  });
}