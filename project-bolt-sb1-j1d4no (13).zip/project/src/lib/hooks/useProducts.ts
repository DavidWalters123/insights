import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { collection, addDoc, updateDoc, doc, query, where, orderBy, getDocs, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { toast } from 'react-hot-toast';
import type { Product } from '../types';

export function useProducts(creatorId?: string) {
  const queryClient = useQueryClient();

  const productsQuery = useQuery({
    queryKey: ['products', creatorId],
    queryFn: async () => {
      try {
        const q = creatorId 
          ? query(
              collection(db, 'products'),
              where('creator_id', '==', creatorId),
              orderBy('created_at', 'desc')
            )
          : query(
              collection(db, 'products'),
              orderBy('created_at', 'desc')
            );

        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Product[];
      } catch (error) {
        console.error('Error loading products:', error);
        toast.error('Failed to load products');
        throw error;
      }
    }
  });

  const createProductMutation = useMutation({
    mutationFn: async (productData: Partial<Product>) => {
      if (!auth.currentUser) throw new Error('Must be logged in');

      const docRef = await addDoc(collection(db, 'products'), {
        ...productData,
        creator_id: auth.currentUser.uid,
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
        status: 'draft',
        metrics: {
          total_sales: 0,
          avg_rating: 0,
          review_count: 0
        }
      });

      return { id: docRef.id, ...productData };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Product created successfully');
    },
    onError: (error) => {
      console.error('Error creating product:', error);
      toast.error('Failed to create product');
    }
  });

  const updateProductMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Product> }) => {
      const productRef = doc(db, 'products', id);
      await updateDoc(productRef, {
        ...data,
        updated_at: serverTimestamp()
      });
      return { id, ...data };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast.success('Product updated successfully');
    },
    onError: (error) => {
      console.error('Error updating product:', error);
      toast.error('Failed to update product');
    }
  });

  return {
    products: productsQuery.data || [],
    isLoading: productsQuery.isLoading,
    error: productsQuery.error,
    createProduct: createProductMutation.mutate,
    updateProduct: updateProductMutation.mutate
  };
}