import { useQuery } from '@tanstack/react-query';
import { collection, query, getDocs, orderBy, where } from 'firebase/firestore';
import { db } from '../firebase';
import { toast } from 'react-hot-toast';
import type { Course } from '../types';

export function useCourses() {
  return useQuery({
    queryKey: ['courses'],
    queryFn: async () => {
      try {
        const coursesQuery = query(
          collection(db, 'courses'),
          orderBy('created_at', 'desc') 
        );
        
        const snapshot = await getDocs(coursesQuery);
        const courses = snapshot.docs.map(doc => {
          const data = doc.data();
          // Initialize metrics if they don't exist
          if (!data.metrics) {
            data.metrics = {
              total_students: 0,
              avg_rating: 0,
              completion_rate: 0,
              total_reviews: 0
            };
          }
          return {
            id: doc.id,
            ...data
          };
        });
        return courses;
      } catch (error) {
        console.error('Error loading courses:', error);
        toast.error('Failed to load courses');
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: 2
  });
}