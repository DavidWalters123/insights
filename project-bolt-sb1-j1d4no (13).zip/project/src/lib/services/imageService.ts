import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage, db, auth } from '../firebase';
import { toast } from 'react-hot-toast';

export async function uploadImage(file: File | Blob, options: {
  folder?: string;
  maxSizeInMB?: number;
  quality?: number;
} = {}): Promise<string> {
  if (!auth.currentUser) {
    throw new Error('Must be logged in to upload images');
  }

  const { folder = 'images', maxSizeInMB = 5, quality = 0.8 } = options;

  try {
    // Validate file size
    if (file.size > maxSizeInMB * 1024 * 1024) {
      throw new Error(`File size must be less than ${maxSizeInMB}MB`);
    }

    // Create storage reference with user ID and timestamp
    const timestamp = Date.now();
    const fileName = `${auth.currentUser.uid}/${timestamp}.jpg`;
    const storageRef = ref(storage, `${folder}/${fileName}`);

    // Upload file with metadata
    const metadata = {
      contentType: 'image/jpeg',
      customMetadata: {
        uploadedBy: auth.currentUser.uid,
        uploadedAt: new Date().toISOString()
      }
    };

    const snapshot = await uploadBytes(storageRef, file, metadata);
    const downloadUrl = await getDownloadURL(snapshot.ref);
    
    toast.success('Image uploaded successfully');
    return downloadUrl;
  } catch (error) {
    console.error('Upload error:', error);
    toast.error('Failed to upload image');
    throw error;
  }
}

export async function deleteImage(url: string): Promise<void> {
  try {
    const imageRef = ref(storage, url);
    await deleteObject(imageRef);
  } catch (error) {
    console.error('Error deleting image:', error);
    throw error;
  }
}