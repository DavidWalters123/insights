import { loadStripe } from '@stripe/stripe-js';
import { collection, addDoc, doc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { toast } from 'react-hot-toast';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export async function createCheckoutSession(productId: string) {
  if (!auth.currentUser) {
    toast.error('Please sign in to make a purchase');
    return null;
  }

  try {
    // Get the product details
    const productDoc = await getDoc(doc(db, 'products', productId));
    if (!productDoc.exists()) {
      throw new Error('Product not found');
    }

    const product = productDoc.data();

    // Create a checkout session
    const checkoutSessionRef = await addDoc(
      collection(db, 'stripe_checkout_sessions'),
      {
        price_amount: product.price * 100, // Convert to cents
        currency: 'usd',
        product_id: productId,
        user_id: auth.currentUser.uid,
        created_at: serverTimestamp(),
        status: 'pending',
        success_url: `${window.location.origin}/purchase/success?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${window.location.origin}/products/${productId}?canceled=true`,
      }
    );

    // Wait for the Cloud Function to create the Stripe session
    let attempts = 0;
    const maxAttempts = 10;
    
    while (attempts < maxAttempts) {
      const snapshot = await getDoc(checkoutSessionRef);
      const data = snapshot.data();
      
      if (data?.client_secret) {
        return data.client_secret;
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
      attempts++;
    }

    throw new Error('Timeout waiting for checkout session');
  } catch (error) {
    console.error('Error creating checkout session:', error);
    toast.error('Failed to initiate checkout');
    return null;
  }
}

export async function handlePurchaseSuccess(sessionId: string) {
  if (!auth.currentUser) return;

  try {
    // Update purchase status in Firestore
    const purchaseRef = doc(db, 'purchases', sessionId);
    await updateDoc(purchaseRef, {
      status: 'completed',
      completed_at: serverTimestamp()
    });

    // Update user's purchases
    const userRef = doc(db, 'users', auth.currentUser.uid);
    await updateDoc(userRef, {
      'purchases.total': increment(1),
      'purchases.last_purchase_at': serverTimestamp()
    });

    toast.success('Purchase completed successfully!');
  } catch (error) {
    console.error('Error handling purchase success:', error);
    toast.error('Error updating purchase status');
  }
}