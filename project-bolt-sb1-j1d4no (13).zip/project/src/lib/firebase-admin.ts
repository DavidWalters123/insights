<content>import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';

const serviceAccount = {
  "type": "service_account",
  "project_id": "insights-61c4a",
  "private_key_id": "dc85ac9df88571c60efffe8dd30d19463373c3dd",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC/WZwe20Vq6oGG\nwmlPno6qzFsk4uYQNPAmso2/3PJSo17JcV7RB+EzA+A5h2OY+NFMXJIva3GGlCnv\nYfNHk82CrTNlL7OgDwrndcUnnRnG3mKZtSKdgjmQSQ0FviJmaWvqeCwId6vXTg8Y\nvkNK9DAod8OOt4oD3fE94YMJxth+plgBer6G3QrORfB+raYiEEfti2X7hnT2UEWo\n12PLj91Z4RNb19YKwXAiuzbqfMzSrovxzzMOKT89Ce4ejsWIH+1W3X0Wwbf9mEVv\n96UaOxubWDa3lr4yz/zScYwJ7X95ab9+S370h9ydp0eG4HpzZA3qHgx5eFNeLaei\nodbApfSjAgMBAAECggEAQcRN2Xkp0caKAEQ/p+LqTB/yz6nAwx8+zz4dZC1PiEGo\naXoyyYt4xmz1mzBCdihG34UNpYi7OzMfeqxizl4pi1l2Sbfsd/3TlJwwyB3B5001\n/Hh6TkKdAE9rT2b7MdHYCn2FPN/MyzKEE9AJFvD4wF/xcdL5d7zHlqo0vJ6AeH6h\nP0QTFDj/1htQ3YrpvosnGQ8dwtInxUZjuq5f4UEAJmX9ps9Q4aKx88b+e/TpLQum\nrw+gl02ksYvnqxGli5M+DJND03VYzwl7TpjwbBvOIKJ1Yk30uSI8Kvz3lFtVrO2T\n9mCcqUeCotG9yWYNDuihRpZpC7vvivcWaIA3HlkYuQKBgQDuXvMOv0bN3iiunvG0\neXmRxZa6f0jN6HrncAemcM+ZybIQGA9UOpzsbWMeGXAXIW2e6UDWHEXwNKmrMsXb\nXLf0GaisB1eozMDhrdzDmXRPZERxDvcXyNZoj0J1dbgn244s6gVNrc/dvJ27/Feq\nCpAXxIwuLzKhvEEfQBb45VE3hQKBgQDNgGtn/nT4uR3ZP3zxlc2ktUpR1nVVxubY\n/Mp7iwr8NVFS1Z8HHY40JZ79YbZPc7aaj08kh3Bz2oiYCPG4UcnmZdJg5pPM7Xco\nNDVTzULs2dHMFSsWuS3a/Dfpl4z6gqWLPOGK0tCi39nchCkRonEDsQj9mXb+JNIS\nCG61RtqwBwKBgFj5G+QvRTBmcezr6vAgP15H0EEAbZ5d3jIwwMpBZVvTyyDyuhYI\nYrZlBhAgEpSvp4kfK1I/72L/ZS0/oFaGvyrfwPOlMfURqBUUnkhsKNvRYzKIEXbR\nQiZ5AqdxLzHBY8oj96LM87+iPYYDZH1Vv/7/IAvFFjMEX5JYi7qPbcc5AoGAY3Ag\niNG4CCKLLvRpoPy75VdT/wWnATqduaGY2O8PAbtK/qofqXHDvbf2luURMqDrWx69\nTQ+8elLkhazOSkJJUBM1GW55VlARuIKKy2InYDSGMBqOHxC7/5rL81xB+3X8ZMOw\n31vjWOy4ntvUg5P227Juh0gbLB7lB5TM/Sqr50ECgYEAoCHmDZdnAiZZG+CNuBRU\nExcrQDQnJz9fWO5EY82k7Tl8N3P6MZK7Q0Tod4eFh9TJ/zFjdyMPoJO0jcQ0+HZl\nYzSrX67T7HhdIZuNESd6e725T1M8PRA59xv+f+73744m4oPe/71U5ochkZLDZvOe\nhpMRb+bgKyyYzTBggMaxFZ4=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-uj2ll@insights-61c4a.iam.gserviceaccount.com",
  "client_id": "114927040112282862985",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-uj2ll%40insights-61c4a.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
};

// Initialize Firebase Admin
const app = initializeApp({
  credential: cert(serviceAccount)
});

// Initialize Firestore
const adminDb = getFirestore(app);

export { adminDb };</content>