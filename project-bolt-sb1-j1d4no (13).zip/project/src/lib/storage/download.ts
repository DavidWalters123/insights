import { ref, getDownloadURL, getMetadata } from 'firebase/storage';
import { storage } from './config';

export async function getFileUrl(path: string): Promise<string> {
  try {
    const fileRef = ref(storage, path);
    return await getDownloadURL(fileRef);
  } catch (error: any) {
    if (error.code === 'storage/object-not-found') {
      throw new Error('File not found');
    }
    throw error;
  }
}

export async function getFileMetadata(path: string) {
  try {
    const fileRef = ref(storage, path);
    return await getMetadata(fileRef);
  } catch (error: any) {
    if (error.code === 'storage/object-not-found') {
      throw new Error('File not found');
    }
    throw error;
  }
}