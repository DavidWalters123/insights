import { UploadOptions } from './types';

const DEFAULT_MAX_SIZE = 5; // 5MB
const DEFAULT_ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

export function validateFile(
  file: File,
  options: UploadOptions
): { valid: boolean; error?: string } {
  const maxSize = (options.maxSizeInMB || DEFAULT_MAX_SIZE) * 1024 * 1024;
  const allowedTypes = options.allowedTypes || DEFAULT_ALLOWED_TYPES;

  if (file.size > maxSize) {
    return {
      valid: false,
      error: `File size must be less than ${options.maxSizeInMB || DEFAULT_MAX_SIZE}MB`
    };
  }

  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: `File type must be one of: ${allowedTypes.join(', ')}`
    };
  }

  return { valid: true };
}