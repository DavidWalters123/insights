import { ref, deleteObject } from 'firebase/storage';
import { storage } from './config';
import { auth } from '../firebase';

export async function deleteFile(path: string): Promise<void> {
  if (!auth.currentUser) {
    throw new Error('Must be authenticated to delete files');
  }

  // Ensure users can only delete their own files
  if (!path.includes(`/${auth.currentUser.uid}/`)) {
    throw new Error('Unauthorized to delete this file');
  }

  try {
    const fileRef = ref(storage, path);
    await deleteObject(fileRef);
  } catch (error: any) {
    if (error.code === 'storage/object-not-found') {
      throw new Error('File not found');
    }
    throw error;
  }
}