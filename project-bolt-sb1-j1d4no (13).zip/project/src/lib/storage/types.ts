export interface UploadOptions {
  folder: string;
  maxSizeInMB?: number;
  allowedTypes?: string[];
  metadata?: Record<string, string>;
  generateUniqueName?: boolean;
  quality?: number;
}

export interface UploadProgress {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
}

export interface UploadResult {
  url: string;
  path: string;
  metadata: {
    contentType: string;
    size: number;
    fullPath: string;
    name: string;
    [key: string]: any;
  };
}