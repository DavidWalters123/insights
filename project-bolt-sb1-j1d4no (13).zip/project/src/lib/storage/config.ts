import { getStorage, connectStorageEmulator } from 'firebase/storage';
import { app } from '../firebase';

// Initialize Firebase Storage
export const storage = getStorage(app);

// Connect to storage emulator in development
if (import.meta.env.DEV) {
  try {
    connectStorageEmulator(storage, 'localhost', 9199);
  } catch (error) {
    console.warn('Storage emulator connection failed:', error);
  }
}

// Storage folder paths
export const STORAGE_PATHS = {
  AVATARS: 'avatars',
  BANNERS: 'banners',
  COURSE_CONTENT: 'course-content',
  COMMUNITY_CONTENT: 'community-content',
  PRODUCTS: 'products'
} as const;