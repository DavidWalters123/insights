import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from './config';
import { validateFile } from './validation';
import { UploadOptions, UploadProgress, UploadResult } from './types';
import { auth } from '../firebase';
import { testStorageConnection } from './test';
import { retry } from '../utils/retry';

export async function uploadFile(
  file: File,
  options: UploadOptions,
  onProgress?: (progress: UploadProgress) => void
): Promise<UploadResult> {
  if (!auth.currentUser) {
    throw new Error('Must be authenticated to upload files');
  }

  // Test connection first
  const isConnected = await retry(() => testStorageConnection(), 3);
  if (!isConnected) {
    throw new Error('Storage connection failed');
  }

  // Validate the file
  const validation = validateFile(file, options);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  // Generate a unique file name if requested
  const timestamp = Date.now();
  const fileName = options.generateUniqueName
    ? `${timestamp}-${Math.random().toString(36).substring(2)}-${file.name}`
    : file.name;

  // Create the full path
  const fullPath = `${options.folder}/${auth.currentUser.uid}/${fileName}`;
  const storageRef = ref(storage, fullPath);

  // Prepare metadata
  const metadata = {
    contentType: file.type,
    cacheControl: 'public, max-age=31536000',
    customMetadata: {
      uploadedBy: auth.currentUser.uid,
      uploadedAt: new Date().toISOString(),
      originalName: file.name,
      ...options.metadata
    }
  };

  // Upload the file
  const uploadTask = uploadBytesResumable(storageRef, file, metadata);

  return new Promise((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        if (onProgress) {
          const progress = Math.round(
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100
          );
          onProgress({
            progress,
            bytesTransferred: snapshot.bytesTransferred,
            totalBytes: snapshot.totalBytes
          });
        }
      },
      (error) => {
        console.error('Upload error:', error);
        reject(error);
      },
      async () => {
        try {
          const url = await getDownloadURL(uploadTask.snapshot.ref);
          resolve({
            url,
            path: fullPath,
            metadata: uploadTask.snapshot.metadata
          });
        } catch (error) {
          reject(error);
        }
      }
    );
  });
}