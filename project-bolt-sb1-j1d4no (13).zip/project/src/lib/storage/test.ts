import { ref, uploadBytes, getDownloadURL, deleteObject, StorageError } from 'firebase/storage';
import { storage } from './config';
import { auth } from '../firebase'; 

export async function testStorageConnection(): Promise<boolean> {
  if (!auth.currentUser) {
    console.error('No authenticated user');
    return false;
  }

  try {
    // Create a small test file
    const testBlob = new Blob(['test'], { type: 'text/plain' });
    const testRef = ref(storage, `_test/connection-test.txt`);
    
    // Upload test file
    await uploadBytes(testRef, testBlob);
    
    // Try to get the download URL
    await getDownloadURL(testRef);
    
    // Clean up test file
    await deleteObject(testRef);
    
    console.log('Firebase Storage connection successful');
    return true;
  } catch (error) {
    const storageError = error as StorageError;
    console.error('Firebase Storage connection failed:', {
      code: storageError.code,
      message: storageError.message,
      serverResponse: storageError.serverResponse
    });
    return false;
  }
}