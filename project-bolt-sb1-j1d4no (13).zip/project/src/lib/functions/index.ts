import { httpsCallable } from 'firebase/functions';
import { functions } from '../firebase';

// Stripe webhook handler
export const handleStripeWebhook = httpsCallable(functions, 'stripeWebhook');

// Comment notifications
export const handleCommentNotification = httpsCallable(functions, 'onCommentCreate');

// Reaction updates
export const handleReactionChange = httpsCallable(functions, 'onReactionChange');
export const handleReactionDelete = httpsCallable(functions, 'onReactionDelete');