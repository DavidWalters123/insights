import React, { useState, useEffect } from 'react';
import { MessageSquare } from 'lucide-react';
import { format } from 'date-fns';
import { collection, query, where, orderBy, getDocs, onSnapshot, doc } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import type { Post, Comment } from '../types';
import CommentList from './CommentList';
import CreateCommentForm from './CreateCommentForm';
import PostReactions from './PostReactions';
import { motion, AnimatePresence } from 'framer-motion';

interface PostCardProps {
  post: Post;
}

export default function PostCard({ post }: PostCardProps) {
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<Comment[]>([]);
  const [commentCount, setCommentCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [reactionCounts, setReactionCounts] = useState(post.reaction_counts || {});

  // Handle Firestore timestamp
  const createdAt = post.created_at?.toDate?.() || new Date();

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;

    if (showComments && post.id) {
      try {
        setLoading(true);
        
        // Create query with proper index fields
        const q = query(
          collection(db, 'comments'),
          where('post_id', '==', post.id),
          orderBy('created_at', 'desc')
        );
        
        // Set up real-time listener
        unsubscribe = onSnapshot(q, 
          (snapshot) => {
            const commentsData = snapshot.docs.map(doc => ({
              id: doc.id,
              ...doc.data()
            })) as Comment[];
            
            setComments(commentsData);
            setCommentCount(snapshot.size);
            setLoading(false);
          },
          (error) => {
            console.error('Error loading comments:', error);
            handleFirestoreError(error);
            setComments([]);
            setLoading(false);
          }
        );
      } catch (error) {
        console.error('Error setting up comments listener:', error);
        handleFirestoreError(error);
        setLoading(false);
      }
    }

    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
    };
  }, [showComments, post.id]);

  // Subscribe to reaction count updates
  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'posts', post.id), (doc) => {
      if (doc.exists()) {
        setReactionCounts(doc.data().reaction_counts || {});
      }
    });

    return () => unsubscribe();
  }, [post.id]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-surface border border-surface-light rounded-lg p-6"
    >
      <div className="flex items-start space-x-3">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-white">
            {post.title}
          </h3>
          <div className="flex items-center space-x-2">
            {post.user?.avatar_url ? (
              <img
                src={post.user.avatar_url}
                alt={post.user.full_name}
                className="h-6 w-6 rounded-full"
              />
            ) : (
              <div className="h-6 w-6 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-primary text-sm font-medium">
                  {post.user?.full_name?.[0] || '?'}
                </span>
              </div>
            )}
            <p className="text-sm text-gray-400">
              Posted by {post.user?.full_name || 'Anonymous'} • {format(createdAt, 'PP')}
            </p>
          </div>
          <div 
            className="mt-2 text-gray-300 prose prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </div>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <PostReactions postId={post.id} reactionCounts={reactionCounts} />
        <button
          onClick={() => setShowComments(!showComments)}
          className="inline-flex items-center space-x-1 text-gray-400 hover:text-primary transition-colors"
        >
          <MessageSquare className="h-4 w-4" />
          <span>{commentCount} Comments</span>
        </button>
      </div>

      <AnimatePresence>
        {showComments && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-6 space-y-6"
          >
            <CreateCommentForm postId={post.id} onCommentCreated={() => {}} />
            <CommentList comments={comments} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}