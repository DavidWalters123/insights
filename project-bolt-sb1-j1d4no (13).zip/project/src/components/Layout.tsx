import React, { useState, useRef } from 'react';
import { Link, useNavigate, useLocation, Outlet } from 'react-router-dom';
import { Home, LogOut, User, BookOpen, Users, Settings, Menu, X } from 'lucide-react';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { toast } from 'react-hot-toast';
import EmailVerification from './EmailVerification';
import NotificationBell from './NotificationBell';
import LanguageSelector from './LanguageSelector';
import { useClickOutside } from '../hooks/useClickOutside';

export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [showDropdown, setShowDropdown] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const mobileMenuRef = useRef<HTMLDivElement>(null);

  useClickOutside(dropdownRef, () => setShowDropdown(false));
  useClickOutside(mobileMenuRef, () => setShowMobileMenu(false));

  const handleSignOut = async () => {
    await signOut(auth);
    toast.success('Signed out successfully');
    navigate('/login');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      setShowDropdown(false);
      setShowMobileMenu(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <nav className="fixed top-0 left-0 right-0 z-50 navbar-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link to="/" className="flex items-center px-2 text-white">
                <span className="text-xl font-bold">$INSIGHTS</span>
              </Link>

              {/* Desktop Navigation */}
              <div className="hidden md:ml-6 md:flex md:space-x-8">
                <Link
                  to="/"
                  className={`inline-flex items-center px-1 pt-1 text-sm font-medium ${
                    location.pathname === '/'
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Home className="h-4 w-4 mr-1" />
                  Home
                </Link>
                <Link
                  to="/communities"
                  className={`inline-flex items-center px-1 pt-1 text-sm font-medium ${
                    location.pathname === '/communities'
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Users className="h-4 w-4 mr-1" />
                  Communities
                </Link>
                <Link
                  to="/products"
                  className={`inline-flex items-center px-1 pt-1 text-sm font-medium ${
                    location.pathname.startsWith('/products')
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <BookOpen className="h-4 w-4 mr-1" />
                  Products
                </Link>
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="flex md:hidden">
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-surface-light focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
              >
                {showMobileMenu ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>

            {/* Desktop right section */}
            <div className="hidden md:flex items-center space-x-4">
              <LanguageSelector />
              <NotificationBell />
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setShowDropdown(!showDropdown)}
                  onKeyDown={handleKeyDown}
                  className="flex items-center focus:outline-none"
                  aria-expanded={showDropdown}
                  aria-haspopup="true"
                >
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary/20 transition-colors">
                    {auth.currentUser?.photoURL ? (
                      <img
                        src={auth.currentUser.photoURL}
                        alt="Profile"
                        className="h-8 w-8 rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-4 w-4 text-primary" />
                    )}
                  </div>
                </button>

                {showDropdown && (
                  <div 
                    className="absolute right-0 mt-2 w-48 bg-surface border border-surface-light rounded-lg shadow-lg py-1 z-50"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="user-menu"
                  >
                    <Link
                      to="/profile"
                      className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-surface-light focus:bg-surface-light focus:outline-none"
                      onClick={() => setShowDropdown(false)}
                      role="menuitem"
                    >
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </Link>
                    <Link
                      to="/settings"
                      className="flex items-center px-4 py-2 text-sm text-gray-300 hover:bg-surface-light focus:bg-surface-light focus:outline-none"
                      onClick={() => setShowDropdown(false)}
                      role="menuitem"
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Settings
                    </Link>
                    <div className="border-t border-surface-light my-1"></div>
                    <button
                      onClick={() => {
                        setShowDropdown(false);
                        handleSignOut();
                      }}
                      className="flex items-center w-full px-4 py-2 text-sm text-red-400 hover:bg-surface-light focus:bg-surface-light focus:outline-none"
                      role="menuitem"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        <div
          ref={mobileMenuRef}
          className={`${
            showMobileMenu ? 'block' : 'hidden'
          } md:hidden bg-surface border-t border-surface-light`}
        >
          <div className="px-2 pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                location.pathname === '/'
                  ? 'bg-primary text-white'
                  : 'text-gray-400 hover:text-white hover:bg-surface-light'
              }`}
              onClick={() => setShowMobileMenu(false)}
            >
              <Home className="h-4 w-4 inline-block mr-2" />
              Home
            </Link>
            <Link
              to="/communities"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                location.pathname === '/communities'
                  ? 'bg-primary text-white'
                  : 'text-gray-400 hover:text-white hover:bg-surface-light'
              }`}
              onClick={() => setShowMobileMenu(false)}
            >
              <Users className="h-4 w-4 inline-block mr-2" />
              Communities
            </Link>
            <Link
              to="/products"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                location.pathname.startsWith('/products')
                  ? 'bg-primary text-white'
                  : 'text-gray-400 hover:text-white hover:bg-surface-light'
              }`}
              onClick={() => setShowMobileMenu(false)}
            >
              <BookOpen className="h-4 w-4 inline-block mr-2" />
              Products
            </Link>
            <Link
              to="/profile"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-400 hover:text-white hover:bg-surface-light"
              onClick={() => setShowMobileMenu(false)}
            >
              <User className="h-4 w-4 inline-block mr-2" />
              Profile
            </Link>
            <Link
              to="/settings"
              className="block px-3 py-2 rounded-md text-base font-medium text-gray-400 hover:text-white hover:bg-surface-light"
              onClick={() => setShowMobileMenu(false)}
            >
              <Settings className="h-4 w-4 inline-block mr-2" />
              Settings
            </Link>
            <button
              onClick={() => {
                setShowMobileMenu(false);
                handleSignOut();
              }}
              className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-red-400 hover:bg-surface-light"
            >
              <LogOut className="h-4 w-4 inline-block mr-2" />
              Sign out
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 mt-16">
        <EmailVerification />
        <Outlet />
      </main>
    </div>
  );
}