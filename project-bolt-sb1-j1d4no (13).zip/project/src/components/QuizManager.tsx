import React, { useState } from 'react';
import { Plus, Save, Trash2, Copy, Eye, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { doc, updateDoc, deleteDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { toast } from 'react-hot-toast';
import type { Quiz } from '../types';

interface QuizManagerProps {
  quiz?: Quiz;
  courseId: string;
  moduleId: string;
  lessonId: string;
  onSave?: (quiz: Quiz) => void;
  onCancel?: () => void;
}

export default function QuizManager({ 
  quiz, 
  courseId,
  moduleId,
  lessonId,
  onSave,
  onCancel 
}: QuizManagerProps) {
  const [formData, setFormData] = useState<Partial<Quiz>>(quiz || {
    title: '',
    description: '',
    passing_score: 70,
    time_limit: 0,
    shuffle_questions: false,
    show_correct_answers: true,
    status: 'draft',
    questions: []
  });

  const [currentQuestion, setCurrentQuestion] = useState<number | null>(null);

  const addQuestion = () => {
    setFormData(prev => ({
      ...prev,
      questions: [
        ...(prev.questions || []),
        {
          id: `q${Date.now()}`,
          text: '',
          options: ['', '', '', ''],
          correct_answer: 0,
          points: 1
        }
      ]
    }));
    setCurrentQuestion((prev?.questions?.length || 0));
  };

  const updateQuestion = (index: number, updates: Partial<Quiz['questions'][0]>) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions?.map((q, i) => 
        i === index ? { ...q, ...updates } : q
      )
    }));
  };

  const removeQuestion = (index: number) => {
    setFormData(prev => ({
      ...prev,
      questions: prev.questions?.filter((_, i) => i !== index)
    }));
    setCurrentQuestion(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      const quizData = {
        ...formData,
        course_id: courseId,
        module_id: moduleId,
        lesson_id: lessonId,
        created_by: auth.currentUser.uid,
        updated_at: serverTimestamp()
      };

      if (quiz?.id) {
        await updateDoc(doc(db, 'quizzes', quiz.id), quizData);
        toast.success('Quiz updated successfully');
      } else {
        const docRef = await addDoc(collection(db, 'quizzes'), {
          ...quizData,
          created_at: serverTimestamp(),
          metrics: {
            total_attempts: 0,
            avg_score: 0,
            pass_rate: 0
          }
        });
        quizData.id = docRef.id;
        toast.success('Quiz created successfully');
      }

      onSave?.(quizData as Quiz);
    } catch (error) {
      console.error('Error saving quiz:', error);
      toast.error('Failed to save quiz');
    }
  };

  return (
    <div className="space-y-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Quiz Title
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Passing Score (%)
            </label>
            <input
              type="number"
              min="0"
              max="100"
              value={formData.passing_score}
              onChange={(e) => setFormData({ ...formData, passing_score: parseInt(e.target.value) })}
              className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">
            Description
          </label>
          <textarea
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={3}
            className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
          />
        </div>

        <div className="flex items-center space-x-4">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.shuffle_questions}
              onChange={(e) => setFormData({ ...formData, shuffle_questions: e.target.checked })}
              className="form-checkbox bg-surface-light border-surface-light text-primary rounded focus:ring-primary"
            />
            <span className="text-sm text-gray-300">Shuffle Questions</span>
          </label>

          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={formData.show_correct_answers}
              onChange={(e) => setFormData({ ...formData, show_correct_answers: e.target.checked })}
              className="form-checkbox bg-surface-light border-surface-light text-primary rounded focus:ring-primary"
            />
            <span className="text-sm text-gray-300">Show Correct Answers</span>
          </label>

          <div className="flex items-center space-x-2">
            <input
              type="number"
              min="0"
              value={formData.time_limit}
              onChange={(e) => setFormData({ ...formData, time_limit: parseInt(e.target.value) })}
              className="w-20 px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
            />
            <span className="text-sm text-gray-300">Time Limit (minutes, 0 for no limit)</span>
          </div>
        </div>

        <div className="border-t border-surface-light pt-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-medium text-white">Questions</h3>
            <button
              type="button"
              onClick={addQuestion}
              className="inline-flex items-center px-3 py-1.5 border border-primary text-sm font-medium rounded-md text-primary hover:bg-primary/10"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Question
            </button>
          </div>

          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-1 space-y-2">
              {formData.questions?.map((question, index) => (
                <button
                  key={question.id}
                  type="button"
                  onClick={() => setCurrentQuestion(index)}
                  className={`w-full p-3 text-left rounded-lg transition-colors ${
                    currentQuestion === index
                      ? 'bg-primary/10 border border-primary'
                      : 'bg-surface-light border border-surface-light hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-white font-medium">
                      Question {index + 1}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeQuestion(index);
                      }}
                      className="text-gray-400 hover:text-red-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="text-sm text-gray-400 truncate">
                    {question.text || 'Untitled Question'}
                  </p>
                </button>
              ))}
            </div>

            <div className="col-span-3">
              <AnimatePresence mode="wait">
                {currentQuestion !== null && formData.questions?.[currentQuestion] && (
                  <motion.div
                    key={currentQuestion}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Question Text
                      </label>
                      <textarea
                        value={formData.questions[currentQuestion].text}
                        onChange={(e) => updateQuestion(currentQuestion, { text: e.target.value })}
                        rows={3}
                        className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
                        required
                      />
                    </div>

                    <div className="space-y-3">
                      <label className="block text-sm font-medium text-gray-300">
                        Answer Options
                      </label>
                      {formData.questions[currentQuestion].options.map((option, optionIndex) => (
                        <div key={optionIndex} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            checked={formData.questions[currentQuestion].correct_answer === optionIndex}
                            onChange={() => updateQuestion(currentQuestion, { correct_answer: optionIndex })}
                            className="form-radio bg-surface-light border-surface-light text-primary focus:ring-primary"
                          />
                          <input
                            type="text"
                            value={option}
                            onChange={(e) => {
                              const newOptions = [...formData.questions[currentQuestion].options];
                              newOptions[optionIndex] = e.target.value;
                              updateQuestion(currentQuestion, { options: newOptions });
                            }}
                            className="flex-1 px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
                            placeholder={`Option ${optionIndex + 1}`}
                            required
                          />
                        </div>
                      ))}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Explanation (Optional)
                      </label>
                      <textarea
                        value={formData.questions[currentQuestion].explanation}
                        onChange={(e) => updateQuestion(currentQuestion, { explanation: e.target.value })}
                        rows={2}
                        className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
                        placeholder="Explain why this answer is correct..."
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-1">
                        Points
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={formData.questions[currentQuestion].points}
                        onChange={(e) => updateQuestion(currentQuestion, { points: parseInt(e.target.value) })}
                        className="w-24 px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
                      />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>

        <div className="flex justify-end space-x-4 pt-6 border-t border-surface-light">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 text-sm font-medium text-gray-400 hover:text-white"
            >
              Cancel
            </button>
          )}
          <button
            type="submit"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90"
          >
            <Save className="h-4 w-4 mr-2" />
            {quiz ? 'Update Quiz' : 'Create Quiz'}
          </button>
        </div>
      </form>
    </div>
  );
}