import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Users, Edit2, Trash2 } from 'lucide-react';
import { doc, deleteDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';
import type { Product } from '../types';
import BannerUpload from './BannerUpload';

interface ProductCardProps {
  product: Product;
  showActions?: boolean;
}

export default function ProductCard({ product, showActions = true }: ProductCardProps) {
  const isOwner = auth.currentUser?.uid === product.creator_id;

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!window.confirm('Are you sure you want to delete this product?')) return;

    try {
      await deleteDoc(doc(db, 'products', product.id));
      toast.success('Product deleted successfully');
    } catch (error) {
      console.error('Error deleting product:', error);
      toast.error('Failed to delete product');
    }
  };

  return (
    <div className="relative group bg-surface border border-surface-light rounded-lg overflow-hidden hover:border-primary/50 transition-colors">
      {isOwner && (
        <div className="absolute top-4 right-4 space-x-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
          <Link
            to={`/products/${product.id}/edit`}
            className="inline-flex items-center p-2 bg-primary/90 text-white rounded-full hover:bg-primary"
            onClick={(e) => e.stopPropagation()}
          >
            <Edit2 className="h-4 w-4" />
          </Link>
          <button
            onClick={handleDelete}
            className="p-2 bg-red-500/90 text-white rounded-full hover:bg-red-500"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      )}

      <div className="relative h-48">
        {product.banner_url ? (
          <img
            src={product.banner_url}
            alt={product.title}
            className="w-full h-48 object-cover"
          />
        ) : (
          <div className="w-full h-48 bg-gradient-to-r from-primary/20 to-primary/10 flex items-center justify-center">
            <BookOpen className="h-12 w-12 text-primary" />
          </div>
        )}
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <span className="px-2 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full capitalize">
              {product.type}
            </span>
          </div>
          <div className="text-lg font-bold text-white">
            ${product.price?.toFixed(2)}
          </div>
        </div>

        <h3 className="text-xl font-semibold text-white mb-2">
          {product.title}
        </h3>

        <p className="text-gray-400 mb-4 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center justify-between text-sm text-gray-400">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            {product.delivery_method === 'live' ? 'Live Session' : 'On Demand'}
          </div>
          <div className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            {product.enrolled_count || 0} enrolled
          </div>
        </div>

        {showActions && (
          <div className="mt-6 flex space-x-3">
            <Link
              to={`/products/${product.id}`}
              className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-surface-light text-sm font-medium rounded-md text-white hover:bg-surface-light transition-colors"
            >
              Learn More
            </Link>
            <button
              onClick={() => {/* Handle purchase */}}
              className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90 transition-colors"
            >
              <DollarSign className="h-4 w-4 mr-1" />
              Purchase
            </button>
          </div>
        )}
      </div>
    </div>
  );
}