import React from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import Link from '@tiptap/extension-link';
import {
  Bold,
  Italic,
  Strikethrough,
  Code,
  List,
  ListOrdered,
  Link as LinkIcon,
  Heading1,
  Heading2
} from 'lucide-react';

interface RichTextEditorProps {
  content: string;
  onChange: (content: string) => void;
  placeholder?: string;
}

export default function RichTextEditor({ content, onChange, placeholder }: RichTextEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: {
          levels: [1, 2]
        }
      }),
      Placeholder.configure({
        placeholder: placeholder || 'Write something...',
      }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-primary hover:text-primary/90 underline',
        },
      }),
    ],
    content,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      handleKeyDown: (view, event) => {
        // Prevent form submission on Enter
        if (event.key === 'Enter' && event.ctrlKey) {
          event.preventDefault();
          return true;
        }
        return false;
      },
    }
  });

  if (!editor) {
    return null;
  }

  const toggleLink = () => {
    const previousUrl = editor.getAttributes('link').href;
    const url = window.prompt('URL', previousUrl);

    if (url === null) {
      return;
    }

    if (url === '') {
      editor.chain().focus().extendMarkRange('link').unsetLink().run();
      return;
    }

    editor.chain().focus().extendMarkRange('link').setLink({ href: url }).run();
  };

  const getButtonClass = (isActive: boolean) => `
    p-2 rounded transition-colors ${
      isActive 
        ? 'bg-primary/20 text-primary' 
        : 'text-gray-400 hover:text-white hover:bg-surface-light'
    }
  `;

  return (
    <div className="border border-surface-light rounded-lg overflow-hidden bg-surface-light/50 transition-colors">
      <div className="bg-surface-light border-b border-surface-light p-2 flex flex-wrap gap-1">
        <button
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          type="button"
          className={getButtonClass(editor.isActive('heading', { level: 1 }))}
        >
          <Heading1 className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          type="button"
          className={getButtonClass(editor.isActive('heading', { level: 2 }))}
        >
          <Heading2 className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleBold().run()}
          type="button"
          className={getButtonClass(editor.isActive('bold'))}
        >
          <Bold className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleItalic().run()}
          type="button"
          className={getButtonClass(editor.isActive('italic'))}
        >
          <Italic className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleStrike().run()}
          type="button"
          className={getButtonClass(editor.isActive('strike'))}
        >
          <Strikethrough className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleCode().run()}
          type="button"
          className={getButtonClass(editor.isActive('code'))}
        >
          <Code className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          type="button"
          className={getButtonClass(editor.isActive('bulletList'))}
        >
          <List className="h-4 w-4" />
        </button>
        <button
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          type="button"
          className={getButtonClass(editor.isActive('orderedList'))}
        >
          <ListOrdered className="h-4 w-4" />
        </button>
        <button
          onClick={toggleLink}
          type="button"
          className={getButtonClass(editor.isActive('link'))}
        >
          <LinkIcon className="h-4 w-4" />
        </button>
      </div>
      <EditorContent
        editor={editor}
        className="prose prose-invert max-w-none focus:outline-none bg-surface-light/30 transition-colors p-4 min-h-[200px]"
      />
    </div>
  );
}