import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../lib/hooks/useAuth';
import LoadingState from './LoadingState';
import { toast } from 'react-hot-toast';

interface AuthGuardProps {
  children: React.ReactNode;
  requireVerification?: boolean;
}

export default function AuthGuard({ children, requireVerification = false }: AuthGuardProps) {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingState />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (requireVerification && !user.emailVerified) {
    toast.error('Please verify your email to access this feature');
    return <Navigate to="/" replace />;
  }
  return <>{children}</>;
}