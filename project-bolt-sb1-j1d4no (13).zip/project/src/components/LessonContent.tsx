import React, { useState } from 'react';
import { Video, FileText, PenTool, Edit2 } from 'lucide-react';
import type { Lesson, QuizAttempt, Quiz } from '../types';
import QuizLesson from './QuizLesson';
import QuizManager from './QuizManager';
import { toast } from 'react-hot-toast';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface LessonContentProps {
  lesson: Lesson;
  isAdmin?: boolean;
  onQuizComplete?: (attempt: QuizAttempt) => void;
}

export default function LessonContent({ lesson, isAdmin, onQuizComplete }: LessonContentProps) {
  const [editingQuiz, setEditingQuiz] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleQuizSave = async (updatedQuiz: Quiz) => {
    try {
      setSaving(true);
      await updateDoc(doc(db, 'quizzes', updatedQuiz.id), {
        ...updatedQuiz,
        updated_at: serverTimestamp()
      });
      toast.success('Quiz updated successfully');
      setEditingQuiz(false);
    } catch (error) {
      console.error('Error updating quiz:', error);
      toast.error('Failed to update quiz');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-surface border border-surface-light rounded-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            {lesson.type === 'quiz' ? (
              <PenTool className="h-6 w-6 text-primary" />
            ) : lesson.type === 'video' ? (
              <Video className="h-6 w-6 text-primary" />
            ) : (
              <FileText className="h-6 w-6 text-primary" />
            )}
            <h2 className="text-xl font-semibold text-white">{lesson.title}</h2>
          </div>
          {isAdmin && lesson.type === 'quiz' && (
            <button
              onClick={() => setEditingQuiz(!editingQuiz)}
              className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-primary hover:bg-primary/10 rounded-md"
              disabled={saving}
            >
              <Edit2 className="h-4 w-4 mr-1" />
              {saving ? 'Saving...' : editingQuiz ? 'Cancel Editing' : 'Edit Quiz'}
            </button>
          )}
        </div>
        
        {lesson.type === 'quiz' && editingQuiz ? (
          <QuizManager
            quiz={lesson.quiz}
            courseId={lesson.course_id}
            moduleId={lesson.module_id}
            lessonId={lesson.id}
            onSave={handleQuizSave}
            onCancel={() => setEditingQuiz(false)}
          />
        ) : lesson.type === 'quiz' ? (
          <QuizLesson
            quiz={lesson.quiz!}
            onComplete={onQuizComplete!}
          />
        ) : lesson.type === 'video' && lesson.video_url ? (
          <div className="aspect-video">
            <iframe
              src={lesson.video_url}
              title={lesson.title}
              className="w-full h-full rounded-lg"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        ) : (
          <div 
            className="prose prose-invert max-w-none"
            dangerouslySetInnerHTML={{ __html: lesson.content }}
          />
        )}
      </div>
    </div>
  );
}