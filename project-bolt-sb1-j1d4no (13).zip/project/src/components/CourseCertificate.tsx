import React from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import type { Certificate } from '../types';
import { motion } from 'framer-motion';
import { Download, Award } from 'lucide-react';
import { toast } from 'react-hot-toast';

interface CourseCertificateProps {
  certificate: Certificate;
  onDownload?: () => void;
}

export default function CourseCertificate({ certificate, onDownload }: CourseCertificateProps) {
  const certificateRef = React.useRef<HTMLDivElement>(null);

  const downloadCertificate = async () => {
    if (!certificateRef.current) return;

    try {
      const canvas = await html2canvas(certificateRef.current, {
        scale: 2,
        logging: false,
        useCORS: true
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [canvas.width, canvas.height]
      });

      pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`${certificate.template_data.course_name.replace(/\s+/g, '-')}-certificate.pdf`);
      
      onDownload?.();
      toast.success('Certificate downloaded successfully');
    } catch (error) {
      console.error('Error generating certificate:', error);
      toast.error('Failed to generate certificate');
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        ref={certificateRef}
        className="bg-white p-16 rounded-lg shadow-lg"
        style={{ width: '1000px', height: '700px' }}
      >
        <div className="border-8 border-primary/20 h-full flex flex-col items-center justify-center p-8">
          <Award className="h-16 w-16 text-primary mb-8" />
          
          <div className="text-center space-y-8">
            <h1 className="text-4xl font-bold text-gray-900">
              Certificate of Completion
            </h1>
            
            <p className="text-xl text-gray-600">
              This is to certify that
            </p>
            
            <p className="text-3xl font-bold text-primary">
              {certificate.template_data.student_name}
            </p>
            
            <p className="text-xl text-gray-600">
              has successfully completed the course
            </p>
            
            <p className="text-2xl font-bold text-gray-900">
              {certificate.template_data.course_name}
            </p>
            
            <div className="pt-8">
              <p className="text-gray-600">
                Completed on {certificate.template_data.completion_date}
              </p>
              {certificate.template_data.instructor_name && (
                <p className="text-gray-600 mt-4">
                  Instructor: {certificate.template_data.instructor_name}
                </p>
              )}
              <p className="text-sm text-gray-500 mt-4">
                Certificate ID: {certificate.template_data.certificate_number}
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={downloadCertificate}
        className="w-full flex items-center justify-center px-4 py-3 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors"
      >
        <Download className="h-5 w-5 mr-2" />
        Download Certificate
      </motion.button>
    </div>
  );
}