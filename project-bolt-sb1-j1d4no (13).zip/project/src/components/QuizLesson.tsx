import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, AlertTriangle, Trophy } from 'lucide-react';
import type { Quiz, QuizAttempt } from '../types';
import { toast } from 'react-hot-toast';

interface QuizLessonProps {
  quiz: Quiz;
  onComplete: (attempt: QuizAttempt) => void;
}

export default function QuizLesson({ quiz, onComplete }: QuizLessonProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleAnswer = (answerIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);
  };

  const calculateScore = () => {
    let correct = 0;
    answers.forEach((answer, index) => {
      if (answer === quiz.questions[index].correct_answer) {
        correct++;
      }
    });
    return Math.round((correct / quiz.questions.length) * 100);
  };

  const handleSubmit = async () => {
    try {
      setSubmitting(true);
      const score = calculateScore();
      
      if (score >= quiz.passing_score) {
        toast.success('Congratulations! You passed the quiz! 🎉');
      } else {
        toast.error('You did not meet the passing score. Try again!');
      }

      await onComplete({
        quiz_id: quiz.id,
        score,
        answers: answers.map((answer, index) => ({
          question_id: quiz.questions[index].id,
          selected_answer: answer
        })),
        passed: score >= quiz.passing_score
      });

      setShowResults(true);
    } catch (error) {
      console.error('Error submitting quiz:', error);
      toast.error('Failed to submit quiz');
    } finally {
      setSubmitting(false);
    }
  };

  const currentQ = quiz.questions[currentQuestion];

  if (showResults) {
    const score = calculateScore();
    const passed = score >= quiz.passing_score;

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-surface border border-surface-light rounded-lg p-6"
      >
        <div className="text-center mb-8">
          {passed ? (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="inline-block"
            >
              <Trophy className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            </motion.div>
          ) : (
            <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          )}
          <h2 className="text-2xl font-bold text-white mb-2">
            {passed ? 'Quiz Completed!' : 'Quiz Failed'}
          </h2>
          <p className="text-gray-400">
            You scored {score}% (Required: {quiz.passing_score}%)
          </p>
        </div>

        <div className="space-y-6">
          {quiz.questions.map((question, index) => {
            const isCorrect = answers[index] === question.correct_answer;
            
            return (
              <div key={question.id} className="bg-surface-light rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  {isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-green-500 mt-1" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 mt-1" />
                  )}
                  <div className="flex-1">
                    <p className="text-white font-medium mb-3">{question.text}</p>
                    <div className="space-y-2">
                      {question.options.map((option, optionIndex) => (
                        <div
                          key={optionIndex}
                          className={`p-3 rounded-lg ${
                            optionIndex === question.correct_answer
                              ? 'bg-green-500/10 text-green-500'
                              : optionIndex === answers[index]
                              ? 'bg-red-500/10 text-red-500'
                              : 'bg-surface text-gray-400'
                          }`}
                        >
                          {option}
                        </div>
                      ))}
                    </div>
                    {question.explanation && (
                      <p className="mt-3 text-sm text-gray-400">
                        {question.explanation}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-surface border border-surface-light rounded-lg p-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-white">
          Question {currentQuestion + 1} of {quiz.questions.length}
        </h2>
        <div className="text-sm text-gray-400">
          Passing score: {quiz.passing_score}%
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentQuestion}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="space-y-6"
        >
          <p className="text-lg text-white">{currentQ.text}</p>

          <div className="space-y-3">
            {currentQ.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                className={`w-full p-4 text-left rounded-lg transition-colors ${
                  answers[currentQuestion] === index
                    ? 'bg-primary/10 border border-primary text-white'
                    : 'bg-surface-light border border-surface-light text-gray-300 hover:border-primary/50'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between mt-8">
        <button
          onClick={() => setCurrentQuestion(currentQuestion - 1)}
          disabled={currentQuestion === 0}
          className="px-4 py-2 text-sm font-medium text-white bg-surface-light rounded-md disabled:opacity-50"
        >
          Previous
        </button>

        {currentQuestion === quiz.questions.length - 1 ? (
          <button
            onClick={handleSubmit}
            disabled={answers.length !== quiz.questions.length || submitting}
            className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-primary/90 disabled:opacity-50"
          >
            {submitting ? 'Submitting...' : 'Submit Quiz'}
          </button>
        ) : (
          <button
            onClick={() => setCurrentQuestion(currentQuestion + 1)}
            disabled={answers[currentQuestion] === undefined}
            className="px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-primary/90 disabled:opacity-50"
          >
            Next Question
          </button>
        )}
      </div>
    </motion.div>
  );
}