import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { User, Upload, Camera, Loader } from 'lucide-react';
import { uploadFile } from '../lib/storage/upload';
import { STORAGE_PATHS } from '../lib/storage/config';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';
import { testStorageConnection } from '../lib/storage/test';
import { doc, updateDoc } from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { serverTimestamp } from 'firebase/firestore';

interface AvatarUploadProps {
  currentAvatarUrl?: string;
  onAvatarChange: (url: string) => void;
  size?: 'sm' | 'md' | 'lg';
}

export default function AvatarUpload({
  currentAvatarUrl,
  onAvatarChange,
  size = 'md',
}: AvatarUploadProps) {
  const [uploading, setUploading] = React.useState(false);
  const [progress, setProgress] = React.useState(0);

  const sizeClasses = {
    sm: 'w-20 h-20',
    md: 'w-32 h-32',
    lg: 'w-40 h-40'
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    
    // Test storage connection first
    const isConnected = await testStorageConnection();
    if (!isConnected) {
      toast.error('Unable to connect to storage. Please try again.');
      return;
    }

    try {
      setUploading(true);
      const result = await uploadFile(file, {
        folder: STORAGE_PATHS.AVATARS,
        maxSizeInMB: 5,
        generateUniqueName: true,
        allowedTypes: ['image/jpeg', 'image/png', 'image/webp'],
        metadata: {
          purpose: 'avatar',
          originalName: file.name
        }
      }, (progress) => {
        console.log('Upload progress:', progress);
        setProgress(progress.progress);
      });

      // Update user profile in Firestore
      if (auth.currentUser) {
        await updateDoc(doc(db, 'users', auth.currentUser.uid), {
          avatar_url: result.url,
          updated_at: serverTimestamp()
        });
        console.log('Profile updated with new avatar:', result.url);
      }

      onAvatarChange(result.url);
      toast.success('Profile photo updated');
    } catch (error) {
      console.error('Upload error:', error);
      // More detailed error message
      const errorMessage = error instanceof Error 
        ? `Upload failed: ${error.message}`
        : 'Failed to upload profile photo';
      toast.error(errorMessage);
      setProgress(0);
    } finally {
      setUploading(false);
    }
  }, [onAvatarChange]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/webp': ['.webp']
    },
    maxFiles: 1,
    disabled: uploading
  });

  return (
    <div {...getRootProps()} className="relative cursor-pointer">
      <input {...getInputProps()} />
      <div className={`${sizeClasses[size]} rounded-full overflow-hidden bg-surface-light border-4 border-surface flex items-center justify-center group relative`}>
        <motion.div className="relative w-full h-full">
          {currentAvatarUrl ? (
            <>
              <img
                src={currentAvatarUrl}
                alt="Profile"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera className="h-8 w-8 text-white" />
              </div>
            </>
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              {uploading ? (
                <div className="text-center">
                  <Loader className="h-8 w-8 text-primary animate-spin mx-auto mb-2" />
                  <p className="text-sm text-white">{progress}%</p>
                </div>
              ) : isDragActive ? (
                <Upload className="h-8 w-8 text-primary" />
              ) : (
                <User className="h-1/3 w-1/3 text-gray-400" />
              )}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}