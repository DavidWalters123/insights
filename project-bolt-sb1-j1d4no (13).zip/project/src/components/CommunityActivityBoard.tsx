import React, { useState, useEffect } from 'react';
import { format, subYears, eachDayOfInterval, isSameDay } from 'date-fns';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import { Activity, AlertTriangle, Users, MessageSquare, BookOpen, Calendar } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { Tooltip } from './Tooltip';
import { motion } from 'framer-motion';

interface CommunityActivityBoardProps {
  communityId: string;
}

interface ActivityData {
  date: Date;
  count: number;
  type: 'post' | 'comment' | 'contribution';
  details?: {
    posts?: number;
    comments?: number;
    likes?: number;
  };
}

export default function CommunityActivityBoard({ communityId }: CommunityActivityBoardProps) {
  const [activityData, setActivityData] = useState<ActivityData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [stats, setStats] = useState({
    totalComments: 0,
    totalEnrollments: 0,
    activeDays: 0
  });

  useEffect(() => {
    loadActivities();
  }, [communityId]);

  async function loadActivities() {
    try {
      setLoading(true);
      setError(null);

      const activitiesQuery = query(
        collection(db, 'activities'),
        where('community_id', '==', communityId),
        orderBy('created_at', 'desc'),
        limit(100)
      );

      const snapshot = await getDocs(activitiesQuery);
      const activities = snapshot.docs.map(doc => ({
        date: doc.data().created_at?.toDate() || new Date(),
        count: 1,
        type: doc.data().type,
        details: doc.data().details || {}
      }));

      // Group activities by date
      const groupedActivities = activities.reduce((acc, activity) => {
        const dateKey = activity.date.toISOString().split('T')[0];
        if (!acc[dateKey]) {
          acc[dateKey] = {
            date: activity.date,
            count: 0,
            type: activity.type,
            details: { comments: 0, enrollments: 0 }
          };
        }
        acc[dateKey].count++;
        if (activity.type === 'comment') acc[dateKey].details.comments++;
        if (activity.type === 'enrollment') acc[dateKey].details.enrollments++;
        return acc;
      }, {} as Record<string, ActivityData>);

      setActivityData(Object.values(groupedActivities));
      
      // Update stats
      setStats({
        totalComments: activities.filter(a => a.type === 'comment').length,
        totalEnrollments: activities.filter(a => a.type === 'enrollment').length,
        activeDays: Object.keys(groupedActivities).length
      });
    } catch (error) {
      console.error('Error loading activities:', error);
      setError(error instanceof Error ? error : new Error('Failed to load activities'));
    } finally {
      setLoading(false);
    }
  }

  const getIntensityClass = (count: number) => {
    if (count === 0) return 'bg-surface-light/70 hover:bg-surface-light/80';
    if (count <= 3) return 'bg-primary/25 hover:bg-primary/35';
    if (count <= 6) return 'bg-primary/50 hover:bg-primary/60';
    if (count <= 9) return 'bg-primary/75 hover:bg-primary/85';
    return 'bg-primary hover:bg-primary/90';
  };

  const renderTooltipContent = (day: Date, activity?: ActivityData) => {
    const count = activity?.count || 0;
    return (
      <div className="text-white text-sm bg-surface-light/95 p-2 rounded-lg border border-surface-light shadow-xl">
        <div className="flex items-center space-x-2 mb-1">
          <Calendar className="h-4 w-4 text-primary" />
          <span className="font-medium">{format(day, 'MMMM d, yyyy')}</span>
        </div>
        <div className="font-bold text-lg mb-1">
          {count} {count === 1 ? 'contribution' : 'contributions'}
        </div>
        {activity?.details && (
          <div className="text-gray-300 space-y-1 border-t border-surface-light/20 pt-1 mt-1">
            {activity.details.comments > 0 && (
              <div className="flex items-center space-x-2">
                <MessageSquare className="h-3 w-3 text-blue-400" />
                <span>{activity.details.comments} comments</span>
              </div>
            )}
            {activity.details.enrollments > 0 && (
              <div className="flex items-center space-x-2">
                <Users className="h-3 w-3 text-green-400" />
                <span>{activity.details.enrollments} enrollments</span>
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <Activity className="h-6 w-6 text-primary animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-48 text-center">
        <AlertTriangle className="h-8 w-8 text-red-500 mb-2" />
        <p className="text-gray-400 mb-4">{error.message}</p>
        <button
          onClick={loadActivities}
          className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-white">Activity Board</h2>
        <div className="text-sm text-gray-400">
          {stats.activeDays} days of activity
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-surface-light rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Total Comments</p>
              <p className="text-2xl font-bold text-white">{stats.totalComments}</p>
            </div>
            <MessageSquare className="h-6 w-6 text-primary" />
          </div>
        </div>

        <div className="bg-surface-light rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Enrollments</p>
              <p className="text-2xl font-bold text-white">{stats.totalEnrollments}</p>
            </div>
            <BookOpen className="h-6 w-6 text-green-500" />
          </div>
        </div>

        <div className="bg-surface-light rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Days</p>
              <p className="text-2xl font-bold text-white">{stats.activeDays}</p>
            </div>
            <Users className="h-6 w-6 text-yellow-500" />
          </div>
        </div>
      </div>

      <motion.div 
        className="activity-grid-container"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <div className="activity-grid">
          {eachDayOfInterval({
            start: subYears(new Date(), 1),
            end: new Date()
          }).map(day => {
            const activity = activityData.find(a => isSameDay(a.date, day));
            const count = activity?.count || 0;

            return (
              <Tooltip
                key={day.toISOString()}
                content={renderTooltipContent(day, activity)}
                offset={{ x: 0, y: -8 }}
              >
                <motion.div
                  className={`w-3 h-3 rounded-sm ${getIntensityClass(count)} transition-colors duration-300`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  whileHover={{ scale: 1.2, zIndex: 10 }}
                  transition={{ duration: 0.3, delay: Math.random() * 0.2 }}
                />
              </Tooltip>
            );
          })}
        </div>
      </motion.div>

      <div className="flex items-center justify-end space-x-2 text-sm">
        <span className="text-gray-400">Less</span>
        <div className="flex space-x-1">
          <div className="w-3 h-3 rounded-sm bg-surface-light/90" />
          <div className="w-3 h-3 rounded-sm bg-primary/25" />
          <div className="w-3 h-3 rounded-sm bg-primary/50" />
          <div className="w-3 h-3 rounded-sm bg-primary/75" />
          <div className="w-3 h-3 rounded-sm bg-primary" />
        </div>
        <span className="text-gray-400">More</span>
      </div>
    </div>
  );
}