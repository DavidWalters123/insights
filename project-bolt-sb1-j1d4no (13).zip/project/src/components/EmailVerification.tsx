import React, { useState } from 'react';
import { sendEmailVerification } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { Mail, RefreshCw } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';

export default function EmailVerification() {
  const [sending, setSending] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const sendVerification = async () => {
    if (!auth.currentUser || sending || cooldown > 0) return;

    try {
      setSending(true);
      await sendEmailVerification(auth.currentUser);
      toast.success('Verification email sent! Please check your inbox.');
      setCooldown(60); // 60 second cooldown
      
      // Start cooldown timer
      const timer = setInterval(() => {
        setCooldown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } catch (error) {
      console.error('Error sending verification email:', error);
      toast.error('Failed to send verification email');
    } finally {
      setSending(false);
    }
  };

  if (!auth.currentUser || auth.currentUser.emailVerified) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 mb-6"
    >
      <div className="flex items-start space-x-3">
        <Mail className="h-5 w-5 text-yellow-500 mt-0.5" />
        <div className="flex-1">
          <h3 className="text-white font-medium mb-1">Verify Your Email</h3>
          <p className="text-gray-300 text-sm mb-3">
            Please verify your email address to access all features.
          </p>
          <button
            onClick={sendVerification}
            disabled={sending || cooldown > 0}
            className="inline-flex items-center px-3 py-1.5 bg-yellow-500/20 text-yellow-500 rounded-md hover:bg-yellow-500/30 transition-colors disabled:opacity-50"
          >
            {sending ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Mail className="h-4 w-4 mr-2" />
            )}
            {cooldown > 0 
              ? `Resend in ${cooldown}s` 
              : 'Send Verification Email'}
          </button>
        </div>
      </div>
    </motion.div>
  );
}