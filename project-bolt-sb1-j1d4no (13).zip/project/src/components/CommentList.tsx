import React from 'react';
import { format } from 'date-fns';
import type { Comment } from '../types';

interface CommentListProps {
  comments: Comment[];
}

export default function CommentList({ comments }: CommentListProps) {
  return (
    <div className="space-y-4">
      {comments.map((comment) => {
        const createdAt = comment.created_at?.toDate?.() || new Date();
        
        return (
          <div key={comment.id} className="bg-surface-light rounded-lg p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  {comment.user?.avatar_url ? (
                    <img
                      src={comment.user.avatar_url}
                      alt={comment.user.full_name}
                      className="h-8 w-8 rounded-full"
                    />
                  ) : (
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-primary font-medium">
                        {comment.user?.full_name?.[0] || '?'}
                      </span>
                    </div>
                  )}
                  <span className="text-white font-medium">
                    {comment.user?.full_name || 'Anonymous'}
                  </span>
                  <span className="text-gray-400 text-sm">
                    • {format(createdAt, 'PP')}
                  </span>
                </div>
                <p className="mt-2 text-gray-300">{comment.content}</p>
              </div>
            </div>
          </div>
        );
      })}
      {comments.length === 0 && (
        <p className="text-center text-gray-400">No comments yet. Be the first to comment!</p>
      )}
    </div>
  );
}