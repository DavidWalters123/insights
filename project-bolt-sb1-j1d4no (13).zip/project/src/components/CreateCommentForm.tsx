import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { collection, addDoc, serverTimestamp, doc, getDoc, updateDoc, increment } from 'firebase/firestore';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';

interface CreateCommentFormProps {
  postId: string;
  onCommentCreated: () => void;
}

export default function CreateCommentForm({ postId, onCommentCreated }: CreateCommentFormProps) {
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const validateComment = (content: string) => {
    if (!content.trim()) {
      throw new Error('Comment cannot be empty');
    }
    if (content.length > 1000) {
      throw new Error('Comment is too long (max 1000 characters)');
    }
    return content.trim();
  };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    
    if (!auth.currentUser) {
      toast.error('You must be logged in to comment');
      return;
    }

    try {
      setSubmitting(true);

      const validatedContent = validateComment(content);

      // Get the post document first to get the community_id
      const postDoc = await getDoc(doc(db, 'posts', postId));
      if (!postDoc.exists()) {
        throw new Error('Post not found');
      }

      const postData = postDoc.data();

      // Get the latest user data
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (!userDoc.exists()) {
        throw new Error('User data not found');
      }

      const userData = userDoc.data();

      // Create the comment with all required fields
      const commentData = {
        content: validatedContent,
        post_id: postId,
        community_id: postData.community_id,
        user_id: auth.currentUser.uid,
        user: {
          id: auth.currentUser.uid,
          email: auth.currentUser.email,
          full_name: userData.full_name || 'Anonymous',
          username: userData.username,
          avatar_url: userData.avatar_url
        },
        created_at: serverTimestamp(),
        updated_at: serverTimestamp(),
        status: 'active',
        reaction_count: 0,
        replies: []
      };

      // Validate all required fields are present
      if (!commentData.post_id || !commentData.community_id || !commentData.user_id) {
        throw new Error('Missing required comment data');
      }

      // Add the comment
      await addDoc(collection(db, 'comments'), commentData);

      // Update post's comment count
      await updateDoc(doc(db, 'posts', postId), {
        comment_count: increment(1)
      });

      setContent('');
      toast.success('Comment added successfully');
      onCommentCreated();
    } catch (error) {
      console.error('Error creating comment:', error);
      handleFirestoreError(error, 'Failed to add comment');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <motion.form
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onSubmit={handleSubmit}
      className="space-y-4"
    >
      <textarea
        placeholder="Write a comment..."
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="w-full px-3 py-2 bg-surface-light border border-surface-light rounded-md text-white focus:outline-none focus:ring-primary focus:border-primary"
        rows={2}
        disabled={submitting}
        required
      />
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        type="submit"
        disabled={submitting || !content.trim()}
        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90 disabled:opacity-50"
      >
        {submitting ? (
          'Posting...'
        ) : (
          <>
            <Send className="h-4 w-4 mr-1" />
            Comment
          </>
        )}
      </motion.button>
    </motion.form>
  );
}