export interface Comment {
  id: string;
  content: string;
  post_id: string;
  community_id: string;
  user_id: string;
  user: {
    id: string;
    email: string | null;
    full_name: string;
    username?: string;
    avatar_url?: string;
  };
  created_at: any;
  updated_at: any;
  status: 'active' | 'deleted';
  reaction_count: number;
  replies: Comment[];
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'reaction' | 'comment' | 'mention';
  content: string;
  link: string;
  read: boolean;
  read_at?: Date;
  created_at: any;
  data?: Record<string, any>;
}

export interface Post {
  id: string;
  title: string;
  content: string;
  community_id: string;
  user_id: string;
  user?: {
    id: string;
    email: string | null;
    full_name: string;
    username?: string;
    avatar_url?: string;
  };
  created_at: any;
  updated_at?: any;
  reaction_counts: {
    like?: number;
    bookmark?: number;
    celebrate?: number;
  };
}

export interface Quiz {
  id: string;
  title: string;
  course_id: string;
  module_id: string;
  lesson_id: string;
  description?: string;
  passing_score: number;
  time_limit?: number;
  shuffle_questions?: boolean;
  show_correct_answers?: boolean;
  status: 'draft' | 'published';
  created_by: string;
  created_at: any;
  updated_at: any;
  questions: Array<{
    id: string;
    text: string;
    options: string[];
    correct_answer: number;
    explanation?: string;
    points?: number;
  }>;
  metrics?: {
    total_attempts: number;
    avg_score: number;
    pass_rate: number;
  };
}

export interface QuizAttempt {
  id: string;
  user_id: string;
  quiz_id: string;
  score: number;
  completed_at: any;
  answers: Array<{
    question_id: string;
    selected_answer: number;
  }>;
  passed: boolean;
}

export interface Certificate {
  id: string;
  user_id: string;
  course_id: string;
  issued_at: any;
  template_data: {
    student_name: string;
    course_name: string;
    completion_date: string;
    certificate_number: string;
    instructor_name?: string;
  };
}