import { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';

// Import Firebase config
import { auth } from './lib/firebase';
import { firebaseConfig } from './lib/firebaseConfig';

import ProductForm from './pages/ProductForm';
import ErrorBoundary from './components/ErrorBoundary';
import AuthGuard from './components/AuthGuard';
import Layout from './components/Layout';
import AuthForm from './components/AuthForm';
import Home from './pages/Home';
import Profile from './pages/Profile';
import Communities from './pages/Communities';
import Community from './pages/Community';
import NewCommunity from './pages/NewCommunity';
import NewCourse from './pages/NewCourse';
import Course from './pages/Course';
import Courses from './pages/Courses';
import CreatorProfile from './pages/CreatorProfile';
import CreatorStorefront from './pages/CreatorStorefront';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Settings from './pages/Settings';
import Analytics from './pages/Analytics';
import InvitePage from './pages/InvitePage';
import PublicProfile from './pages/PublicProfile';
import PurchaseSuccess from './pages/PurchaseSuccess';

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#1A1B23',
              color: '#fff',
              border: '1px solid #2D2E3A',
            },
          }}
        />
        <Routes>
          {/* Public routes */}
          <Route path="/login" element={<AuthForm />} />
          <Route path="/invite/:code" element={<InvitePage />} />
          <Route path="/:username" element={<PublicProfile />} />
          <Route path="/purchase/success" element={<PurchaseSuccess />} />

          {/* Protected routes */}
          <Route
            path="/"
            element={
              <AuthGuard>
                <Layout />
              </AuthGuard>
            }
          >
            <Route index element={<Home />} />
            <Route path="communities" element={<Communities />} />
            <Route path="communities/new" element={<NewCommunity />} />
            <Route path="communities/:id" element={<Community />} />
            <Route
              path="communities/:communityId/courses/new"
              element={
                <AuthGuard requireVerification={true}>
                  <NewCourse />
                </AuthGuard>
              }
            />
            <Route
              path="communities/:communityId/courses/:courseId"
              element={<Course />}
            />
            <Route path="courses" element={<Courses />} />
            <Route path="profile" element={<Profile />} />
            <Route path="products/new" element={<ProductForm />} />
            <Route path="products/:id/edit" element={<ProductForm />} />
            <Route path="creators/:id" element={<CreatorProfile />} />
            <Route
              path="creators/:id/storefront"
              element={
                <AuthGuard requireVerification={true}>
                  <CreatorStorefront />
                </AuthGuard>
              }
            />
            <Route path="products" element={<Products />} />
            <Route path="products/:id" element={<ProductDetail />} />
            <Route path="settings" element={<Settings />} />
            <Route path="analytics" element={<Analytics />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  );
}