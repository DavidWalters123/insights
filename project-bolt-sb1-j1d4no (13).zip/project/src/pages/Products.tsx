import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, Filter } from 'lucide-react';
import { useProducts } from '../lib/hooks/useProducts';
import ProductCard from '../components/ProductCard';
import { auth } from '../lib/firebase';
import LoadingSkeleton from '../components/LoadingSkeleton';
import { motion, AnimatePresence } from 'framer-motion';
import type { Product } from '../types';

export default function Products() {
  const { products, isLoading } = useProducts();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'course' | 'coaching'>('all');

  const filteredProducts = products?.filter(product => {
    const matchesSearch = 
      product.title.toLowerCase().includes(search.toLowerCase()) ||
      product.description.toLowerCase().includes(search.toLowerCase());
    
    const matchesFilter = filter === 'all' || product.type === filter;
    
    return matchesSearch && matchesFilter;
  }) || [];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">Products</h1>
        {auth.currentUser && (
          <Link
            to="/products/new"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-5 w-5 mr-2" />
            Create Product
          </Link>
        )}
      </div>

      <div className="mb-8 flex space-x-4">
        <div className="relative flex-grow">
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-4 py-2 border border-surface-light bg-surface rounded-md text-white focus:outline-none focus:border-primary"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>

        <div className="flex items-center space-x-2">
          <Filter className="text-gray-400" />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value as 'all' | 'course' | 'coaching')}
            className="px-4 py-2 border border-surface-light bg-surface rounded-md text-white focus:outline-none focus:border-primary"
          >
            <option value="all">All Types</option>
            <option value="course">Courses</option>
            <option value="coaching">Coaching</option>
          </select>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <LoadingSkeleton count={6} type="card" />
          </motion.div>
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} showActions={true} />
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}