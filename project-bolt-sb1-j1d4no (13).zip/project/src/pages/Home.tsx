import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, TrendingUp, Users, Star } from 'lucide-react';
import { useRankings } from '../lib/hooks/useRankings';
import CommunityRankings from '../components/CommunityRankings';
import CreatorRankings from '../components/CreatorRankings';
import { motion, AnimatePresence } from 'framer-motion';
import LoadingSkeleton from '../components/LoadingSkeleton';

export default function Home() {
  const [activeTab, setActiveTab] = useState('creators');
  const [sortBy, setSortBy] = useState<'revenue' | 'students' | 'rating'>('revenue');
  const { data, isLoading, error } = useRankings();

  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="space-y-8"
      >
        <LoadingSkeleton type="banner" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <LoadingSkeleton type="card" count={3} />
        </div>
      </motion.div>
    );
  }

  if (error || !data) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500 mb-4">Failed to load rankings</p>
        <button
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
        >
          Retry
        </button>
      </div>
    );
  }

  const { communities, creators } = data;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-8"
    >
      {/* Header */}
      <div className="flex justify-between items-center">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <h1 className="text-3xl font-bold text-white">Rankings</h1>
          <p className="text-gray-400 mt-2">
            Top performing creators and communities based on revenue and engagement
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Link
            to="/communities/new"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary/90 transition-all duration-200"
          >
            <Plus className="h-4 w-4 mr-1" />
            Create Community
          </Link>
        </motion.div>
      </div>

      {/* Tabs */}
      <div className="border-b border-surface-light">
        <div className="flex space-x-8">
          <button
            onClick={() => setActiveTab('creators')}
            className={`pb-4 relative ${
              activeTab === 'creators'
                ? 'text-primary'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Creators
            {activeTab === 'creators' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('communities')}
            className={`pb-4 relative ${
              activeTab === 'communities'
                ? 'text-primary'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Communities
            {activeTab === 'communities' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
            )}
          </button>
        </div>
      </div>

      {/* Rankings */}
      <div className="bg-surface border border-surface-light rounded-lg p-6">
        <AnimatePresence mode="wait">
          {activeTab === 'creators' ? (
            <CreatorRankings creators={creators} />
          ) : (
            <CommunityRankings 
              communities={communities} 
              sortBy={sortBy}
            />
          )}
        </AnimatePresence>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-surface border border-surface-light rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-white">Total Revenue</h3>
            <TrendingUp className="h-5 w-5 text-green-500" />
          </div>
          <p className="text-3xl font-bold text-white mt-2">
            ${communities.reduce((sum, c) => sum + (c.metrics?.monthly_revenue || 0), 0).toLocaleString()}
          </p>
          <p className="text-sm text-gray-400 mt-1">Across all communities</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-surface border border-surface-light rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-white">Active Students</h3>
            <Users className="h-5 w-5 text-blue-500" />
          </div>
          <p className="text-3xl font-bold text-white mt-2">
            {communities.reduce((sum, c) => sum + (c.metrics?.active_users || 0), 0).toLocaleString()}
          </p>
          <p className="text-sm text-gray-400 mt-1">Learning this month</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-surface border border-surface-light rounded-lg p-6"
        >
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-white">Course Completion</h3>
            <Star className="h-5 w-5 text-yellow-500" />
          </div>
          <p className="text-3xl font-bold text-white mt-2">
            {Math.round(communities.reduce((sum, c) => sum + (c.metrics?.course_completion_rate || 0), 0) / Math.max(communities.length, 1))}%
          </p>
          <p className="text-sm text-gray-400 mt-1">Average completion rate</p>
        </motion.div>
      </div>
    </motion.div>
  );
}