import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, addDoc, deleteDoc, updateDoc, serverTimestamp, orderBy, onSnapshot, increment, setDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import type { Community as CommunityType, Post, CommunityMember, Course, User } from '../types';
import PostCard from '../components/PostCard';
import CreatePostForm from '../components/CreatePostForm';
import MemberList from '../components/MemberList';
import CourseList from '../components/CourseList';
import AdminSettingsModal from '../components/AdminSettingsModal';
import CommunityEvents from '../components/CommunityEvents';
import CommunityAnnouncements from '../components/CommunityAnnouncements';
import CommunityResources from '../components/CommunityResources';
import CommunityActivityBoard from '../components/CommunityActivityBoard';
import CommunityChat from '../components/CommunityChat';
import InviteDialog from '../components/InviteDialog';
import LoadingSkeleton from '../components/LoadingSkeleton';
import BannerUpload from '../components/BannerUpload';
import { Settings, Loader, Plus, UserPlus, MessageSquare, UserMinus } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';

export default function Community() {
  const { id } = useParams();
  const [community, setCommunity] = useState<CommunityType | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [members, setMembers] = useState<(CommunityMember & { user: User })[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isMember, setIsMember] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showInviteDialog, setShowInviteDialog] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [membershipId, setMembershipId] = useState<string | null>(null);

  useEffect(() => {
    if (id && auth.currentUser) {
      loadCommunityData();
    }
  }, [id, auth.currentUser]);

  async function loadCommunityData() {
    if (!id) return;
    
    try {
      setLoading(true);
      setError(null);

      // Load community data first
      const communityDoc = await getDoc(doc(db, 'communities', id));
      if (!communityDoc.exists()) {
        throw new Error('Community not found');
      }

      const communityData = {
        id: communityDoc.id,
        ...communityDoc.data()
      } as CommunityType;

      // Migrate old community if needed
      if (!communityData.metrics) {
        await updateDoc(doc(db, 'communities', id), {
          metrics: {
            total_members: 0,
            total_posts: 0,
            total_courses: 0
          }
        });
        communityData.metrics = {
          total_members: 0,
          total_posts: 0,
          total_courses: 0
        };
      }

      setCommunity(communityData);

      // Check membership status first if user is logged in
      if (auth.currentUser) {
        const memberDocId = `${auth.currentUser.uid}_${communityData.id}`;
        
        const memberDoc = await getDoc(doc(db, 'community_members', memberDocId));
        
        if (memberDoc.exists()) {
          const memberData = memberDoc.data();
          setIsMember(true);
          setIsAdmin(memberData?.role === 'admin');
          setMembershipId(memberDocId);
        } else {
          setIsMember(false);
          setIsAdmin(false);
          setMembershipId(null);
        }
      }
      // Load members with user data
      const membersQuery = query(
        collection(db, 'community_members'),
        where('community_id', '==', id),
        orderBy('joined_at', 'desc')
      );

      const membersSnapshot = await getDocs(membersQuery);
      const membersPromises = membersSnapshot.docs.map(async (memberDoc) => {
        const memberData = {
          id: memberDoc.id,
          ...memberDoc.data()
        } as CommunityMember;

        // Fetch user data for each member
        const userDoc = await getDoc(doc(db, 'users', memberData.user_id));
        const userData = userDoc.exists() ? {
          id: userDoc.id,
          ...userDoc.data()
        } as User : {
          id: memberData.user_id,
          email: '',
          full_name: 'Anonymous User',
          created_at: new Date()
        };

        return {
          ...memberData,
          user: userData
        };
      });

      const membersData = await Promise.all(membersPromises);
      setMembers(membersData);

      // Load posts
      const postsQuery = query(
        collection(db, 'posts'),
        where('community_id', '==', id),
        orderBy('created_at', 'desc')
      );

      const unsubscribePosts = onSnapshot(postsQuery, (snapshot) => {
        const postsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Post[];
        setPosts(postsData);
      });

      // Load courses
      const coursesQuery = query(
        collection(db, 'courses'),
        where('community_id', '==', id),
        orderBy('created_at', 'desc')
      );

      const coursesSnapshot = await getDocs(coursesQuery);
      const coursesData = coursesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Course[];

      setCourses(coursesData);
      setLoading(false);

      return () => {
        unsubscribePosts();
      };
    } catch (error) {
      console.error('Error loading community data:', error);
      setError(error instanceof Error ? error : new Error('Failed to load community'));
      handleFirestoreError(error, 'Failed to load community data');
      setLoading(false);
    }
  }

  async function handleJoinCommunity() {
    if (!auth.currentUser || !community) return;

    try {
      const memberDocId = `${auth.currentUser.uid}_${community.id}`;
      
      const memberData = {
        community_id: community.id,
        user_id: auth.currentUser.uid,
        role: 'member',
        joined_at: serverTimestamp()
      };
      
      await setDoc(doc(db, 'community_members', memberDocId), memberData);

      // Update community metrics
      await updateDoc(doc(db, 'communities', community.id), {
        'metrics.total_members': increment(1)
      });

      setMembershipId(memberDocId);
      setIsMember(true);
      setIsAdmin(false);
      toast.success('Successfully joined community');
      loadCommunityData();
    } catch (error) {
      console.error('Error joining community:', error);
      handleFirestoreError(error, 'Failed to join community');
    }
  }

  async function handleLeaveCommunity() {
    if (!membershipId) return;

    try {
      await deleteDoc(doc(db, 'community_members', membershipId));
      setMembershipId(null);
      setIsMember(false);
      setIsAdmin(false);
      toast.success('Successfully left community');
      loadCommunityData();
    } catch (error) {
      console.error('Error leaving community:', error);
      handleFirestoreError(error, 'Failed to leave community');
    }
  }

  if (loading) {
    return (
      <div className="space-y-8">
        <LoadingSkeleton type="banner" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <LoadingSkeleton type="card" count={3} />
        </div>
      </div>
    );
  }

  if (error || !community) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <p className="text-red-500 mb-4">{error?.message || 'Community not found'}</p>
        <Link
          to="/communities"
          className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
        >
          Back to Communities
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-surface border border-surface-light rounded-lg overflow-hidden">
        <BannerUpload
          currentBannerUrl={community.banner_url}
          onBannerChange={async (url) => {
            try {
              await updateDoc(doc(db, 'communities', community.id), {
                banner_url: url,
                updated_at: serverTimestamp()
              });
              setCommunity(prev => prev ? { ...prev, banner_url: url } : null);
              toast.success('Banner updated successfully');
            } catch (error) {
              handleFirestoreError(error, 'Failed to update banner');
            }
          }}
          height="h-48"
        />
        
        <div className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-white">{community.name}</h1>
              <p className="mt-2 text-gray-300">{community.description}</p>
              <div className="mt-4 flex items-center space-x-4">
                <span className="text-gray-400">
                  {members.length} member{members.length !== 1 ? 's' : ''}
                </span>
                <span className="text-gray-400">
                  {courses.length} course{courses.length !== 1 ? 's' : ''}
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {auth.currentUser && (
                <>
                  {isMember ? (
                    <>
                      <button
                        onClick={() => setShowChat(true)}
                        className="inline-flex items-center px-4 py-2 border border-surface-light text-white rounded-md hover:bg-surface-light transition-all duration-200"
                      >
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Chat
                      </button>
                      <button
                        onClick={handleLeaveCommunity}
                        className="inline-flex items-center px-4 py-2 border border-red-500 text-red-500 rounded-md hover:bg-red-500/10 transition-all duration-200"
                      >
                        <UserMinus className="h-4 w-4 mr-2" />
                        Leave
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={handleJoinCommunity}
                      className="inline-flex items-center px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 transition-all duration-200"
                    >
                      <UserPlus className="h-4 w-4 mr-2" />
                      Join Community
                    </button>
                  )}
                  {isAdmin && (
                    <>
                      <button
                        onClick={() => setShowInviteDialog(true)}
                        className="inline-flex items-center px-4 py-2 border border-primary text-primary rounded-md hover:bg-primary/10 transition-all duration-200"
                      >
                        <UserPlus className="h-4 w-4 mr-2" />
                        Invite
                      </button>
                      <button
                        onClick={() => setShowSettings(true)}
                        className="inline-flex items-center px-4 py-2 border border-surface-light text-white rounded-md hover:bg-surface-light transition-all duration-200"
                      >
                        <Settings className="h-4 w-4 mr-2" />
                        Settings
                      </button>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Posts and Activity */}
        <div className="lg:col-span-2 space-y-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <CommunityActivityBoard communityId={community.id} />
          </motion.div>

          {isMember && (
            <CreatePostForm
              communityId={community.id}
              onPostCreated={loadCommunityData}
            />
          )}

          {posts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}

          {posts.length === 0 && (
            <div className="text-center py-12 text-gray-400">
              No posts yet. Be the first to post!
            </div>
          )}
        </div>

        {/* Right Column - Members and Info */}
        <div className="space-y-8">
          <MemberList
            members={members}
            isAdmin={isAdmin}
            onRemoveMember={async (memberId) => {
              try {
                await deleteDoc(doc(db, 'community_members', memberId));
                toast.success('Member removed');
                loadCommunityData();
              } catch (error) {
                handleFirestoreError(error, 'Failed to remove member');
              }
            }}
          />

          <CourseList
            courses={courses}
            communityId={community.id}
            isAdmin={isAdmin}
            onCourseCreated={loadCommunityData}
          />

          {isMember && (
            <>
              <CommunityAnnouncements
                communityId={community.id}
                isAdmin={isAdmin}
              />
              <CommunityEvents
                communityId={community.id}
                isAdmin={isAdmin}
              />
              <CommunityResources
                communityId={community.id}
                isAdmin={isAdmin}
              />
            </>
          )}
        </div>
      </div>

      {/* Modals */}
      {showSettings && (
        <AdminSettingsModal
          community={community}
          onClose={() => setShowSettings(false)}
          onUpdate={(updates) => {
            setCommunity({ ...community, ...updates });
            setShowSettings(false);
          }}
        />
      )}

      {showInviteDialog && (
        <InviteDialog
          type="community"
          targetId={community.id}
          onClose={() => setShowInviteDialog(false)}
        />
      )}

      {showChat && (
        <CommunityChat
          communityId={community.id}
          onClose={() => setShowChat(false)}
        />
      )}
    </div>
  );
}