import React, { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import { handlePurchaseSuccess } from '../lib/services/stripe';
import { motion } from 'framer-motion';

export default function PurchaseSuccess() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');

  useEffect(() => {
    if (sessionId) {
      handlePurchaseSuccess(sessionId);
    }
  }, [sessionId]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full mx-4 bg-surface border border-surface-light rounded-lg p-8 text-center"
      >
        <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-6" />
        <h1 className="text-2xl font-bold text-white mb-4">
          Purchase Successful!
        </h1>
        <p className="text-gray-400 mb-8">
          Thank you for your purchase. You can now access your content.
        </p>
        <div className="space-y-4">
          <Link
            to="/products"
            className="block w-full px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
          >
            View My Products
          </Link>
          <Link
            to="/"
            className="block w-full px-4 py-2 border border-surface-light text-white rounded-md hover:bg-surface-light"
          >
            Return Home
          </Link>
        </div>
      </motion.div>
    </div>
  );
}