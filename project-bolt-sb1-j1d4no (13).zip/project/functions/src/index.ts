import { onRequest } from "firebase-functions/v2/https";
import { onDocumentCreated, onDocumentDeleted } from "firebase-functions/v2/firestore";
import * as admin from "firebase-admin";
import { Stripe } from "stripe";
import { sendEmail, emailTemplates } from "./email";

admin.initializeApp();

// Stripe webhook handler
export const stripeWebhook = onRequest({
  cors: true,
  secrets: ["STRIPE_WEBHOOK_SECRET"]
}, async (req, res) => {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: "2023-10-16",
  });

  try {
    const sig = req.headers["stripe-signature"]!;
    const event = stripe.webhooks.constructEvent(
      req.rawBody,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );

    switch (event.type) {
      case "checkout.session.completed":
        const session = event.data.object;
        await handleSuccessfulPayment(session);
        break;
    }

    res.json({ received: true });
  } catch (err: any) {
    console.error("Webhook Error:", err);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

// Handle successful payments
async function handleSuccessfulPayment(session: any) {
  const { customer_email, client_reference_id } = session;

  // Update order status
  const orderRef = admin.firestore().doc(`orders/${client_reference_id}`);
  await orderRef.update({
    status: "paid",
    stripeSessionId: session.id,
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  // Send confirmation email
  if (customer_email) {
    const template = emailTemplates.orderConfirmation(session);
    await sendEmail(customer_email, template.subject, template.html);
  }
}

// Update post reaction counts
export const onReactionChange = onDocumentCreated(
  "post_reactions/{reactionId}",
  async (event) => {
    const reaction = event.data?.data();
    if (!reaction) return;

    const postRef = admin.firestore().doc(`posts/${reaction.post_id}`);
    await postRef.update({
      [`reaction_counts.${reaction.type}`]: admin.firestore.FieldValue.increment(1)
    });
  }
);

export const onReactionDelete = onDocumentDeleted(
  "post_reactions/{reactionId}",
  async (event) => {
    const reaction = event.data?.data();
    if (!reaction) return;

    const postRef = admin.firestore().doc(`posts/${reaction.post_id}`);
    await postRef.update({
      [`reaction_counts.${reaction.type}`]: admin.firestore.FieldValue.increment(-1)
    });
  }
);

// Handle comment notifications
export const onCommentCreate = onDocumentCreated(
  "comments/{commentId}",
  async (event) => {
    const comment = event.data?.data();
    if (!comment) return;

    const postRef = admin.firestore().doc(`posts/${comment.post_id}`);
    const postDoc = await postRef.get();
    const post = postDoc.data();

    if (!post) return;

    // Update comment count
    await postRef.update({
      comment_count: admin.firestore.FieldValue.increment(1)
    });

    // Create notification
    await admin.firestore().collection("notifications").add({
      user_id: post.user_id,
      type: "comment",
      content: `${comment.user.full_name} commented on your post`,
      link: `/communities/${post.community_id}/posts/${post.id}`,
      read: false,
      created_at: admin.firestore.FieldValue.serverTimestamp()
    });

    // Send email notification
    const userDoc = await admin.firestore().doc(`users/${post.user_id}`).get();
    const userData = userDoc.data();

    if (userData?.email && userData?.notifications_enabled) {
      const template = emailTemplates.newComment(post.title, comment.content);
      await sendEmail(userData.email, template.subject, template.html);
    }
  }
);