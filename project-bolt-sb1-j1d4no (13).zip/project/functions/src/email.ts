import * as nodemailer from "nodemailer";
import { logger } from "firebase-functions";

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.GMAIL_EMAIL,
    pass: process.env.GMAIL_APP_PASSWORD
  }
});

export async function sendEmail(to: string, subject: string, html: string) {
  try {
    const mailOptions = {
      from: `INSIGHTS <${process.env.GMAIL_EMAIL}>`,
      to,
      subject,
      html
    };

    const info = await transporter.sendMail(mailOptions);
    logger.info("Email sent:", info.messageId);
    return info;
  } catch (error) {
    logger.error("Error sending email:", error);
    throw error;
  }
}

export const emailTemplates = {
  orderConfirmation: (session: any) => ({
    subject: "Order Confirmation - INSIGHTS",
    html: `
      <h1>Thank you for your purchase!</h1>
      <p>Your order has been confirmed and processed successfully.</p>
      <p>Order ID: ${session.id}</p>
    `
  }),

  newComment: (postTitle: string, commentContent: string) => ({
    subject: `New comment on your post: ${postTitle}`,
    html: `
      <h1>New Comment</h1>
      <p>Someone commented on your post "${postTitle}":</p>
      <blockquote>${commentContent}</blockquote>
    `
  })
};